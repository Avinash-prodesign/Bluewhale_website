<?php include("header.php"); ?>
<?php include("sidebar.php"); ?>

<!-- MAIN -->
<div class="main">
    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <!-- OVERVIEW -->
            <div class="panel panel-headline">
                <div class="panel-heading">
                    <h3 class="panel-title">Add New Blog</h3>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                <!-- <form>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Post Title</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Post Title">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Description</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Description">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Date</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Description">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                    </div>
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Check me out</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form> -->
                <form>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="exampleInputEmail1">Post Title</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Post Title">
                        </div>
                        <div class="col-md-6">
                            <label for="exampleInputEmail1">Description</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Description">
                        </div>
                        <div class="col-md-12" style="margin-top:10px;">
                            <label for="exampleInputEmail1">Blog Content</label>
                            <textarea class="form-control" rows="5" id="comment"></textarea>
                        </div>
                        <div class="col-md-6" style="margin-top:10px;">
                            <label for="exampleInputEmail1">Date</label>
                            <input type='text' class="form-control" id='datetimepicker1' placeholder="Select Date" />
                        </div>
                        <div class="col-md-6" style="margin-top:10px;">
                            <label for="exampleInputEmail1">Author</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Author Name">
                        </div>
                        <div class="col-md-6" style="margin-top:10px;">
                            <label for="exampleInputEmail1">File Upload</label>
                            <input type="file" class="form-control-file" id="exampleFormControlFile1">
                        </div>
                        <div class="clearfix "></div>
                        <div class="col-md-6" style="margin-top:15px;">
                            <button class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
                </div>
            </div>

            
            <!-- END OVERVIEW -->
        </div>
    </div>
    <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN -->


<?php include("footer.php"); ?>